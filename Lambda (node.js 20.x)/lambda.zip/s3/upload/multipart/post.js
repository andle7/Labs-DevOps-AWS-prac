const { S3Client, ListPartsCommand, CompleteMultipartUploadCommand } = require("@aws-sdk/client-s3");

const { handleHttpRequest } = require("slsberry");
const apiSpec = {
	category: "http",
	event: [
		{
			type: "REST",
			method: "Post",
		},
	],
	desc: "multipart 업로드를 완료한다.",
	parameters: {
		upload_id: { req: true, type: "string", desc: "upload_id" },
		fileKey: { req: true, type: "string", desc: "fileKey" },
	},
	errors: {
		unexpected_error: { status_code: 500, reason: "알 수 없는 에러" },
		query_failed: { status_code: 500, reason: 'db 쿼리 실행 중 문제가 발생했습니다.' },
	},
	responses: {
		description: "",
		content: "application/json",
		schema: {
			type: "object",
			properties: {
				hashKey: { type: "String", desc: "hash_key" },
			},
		},
	},
};
exports.apiSpec = apiSpec;
async function handler(inputObject, event) {
	const { upload_id, fileKey } = inputObject;

	try {
		const s3Client = new S3Client({
			region: process.env.region,
		});

		const params = {
			Bucket: process.env.file_bucket_name,
			Key: fileKey,
			UploadId: upload_id,
		};
		console.log("listParts params", params);

		const listPartsCommand = new ListPartsCommand(params);
		const listPartsResponse = await s3Client.send(listPartsCommand);
		console.log(listPartsResponse);
		const PartsForCompleteUpload = listPartsResponse.Parts.map((part) => ({
			ETag: part.ETag,
			PartNumber: part.PartNumber,
		}));

		const completeParams = {
			...params,
			MultipartUpload: { Parts: PartsForCompleteUpload },
		};
		console.log(PartsForCompleteUpload);

		const completeMultipartUploadCommand = new CompleteMultipartUploadCommand(completeParams);
		await s3Client.send(completeMultipartUploadCommand);

		return {
			status: 200,
			response: {
				result: "success",
			},
		};

	} catch (e) {
		console.log(e);
		return { predefinedError: apiSpec.errors.unexpected_error };
	}
}
exports.handler = async (event, context) => {
	return await handleHttpRequest(event, context, apiSpec, handler);
};
