const { S3Client, CreateMultipartUploadCommand, UploadPartCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { Base64 } = require('js-base64');
const { handleHttpRequest } = require("slsberry");
const moment = require("moment");
const apiSpec = {
	category: "http",
	event: [
		{
			type: "REST",
			method: "Get",
		},
	],
	desc: "multipart presigned url들을 생성한다",
	parameters: {
		user_id: { req: true, type: "string", desc: "user_id" },

		type: { req: true, type: "string", desc: "type" },
		org_file_name: { req: true, type: "string", desc: "원본 파일 이름름" },
		size: { "req": true, "type": "Integer", "desc": "파일 사이즈" },
	},
	errors: {
		unexpected_error: { status_code: 500, reason: "알 수 없는 에러" },
	},
	responses: {
		description: "",
		content: "application/json",
		schema: {
			type: "object",
			properties: {
				hashKey: { type: "String", desc: "hash_key" },
			},
		},
	},
};
exports.apiSpec = apiSpec;
async function handler(inputObject, event) {
	const { user_id, type, size, org_file_name } = inputObject;

	console.log(inputObject);

	try {
		// url 분리 단위. 5MB 단위로 분리
		let sizeUnit = 5;
		let parts = Math.ceil(size / (1024 * 1024 * sizeUnit));
		let metadata = {};
		metadata["user_id"] = user_id;
		metadata["type"] = type;
		// 한글은 base64 필요
		metadata["org_file_name"] = Base64.encode(org_file_name);

		const s3Params = {
			Bucket: process.env.file_bucket_name,
			Key: org_file_name,
			Expires: moment().add(6000, 'seconds').toDate(),
			Metadata: metadata,
		};
		console.log(s3Params);

		const s3Client = new S3Client({
			region: process.env.region,
		});

		const createMultipartUploadCommand = new CreateMultipartUploadCommand(s3Params);
		const multipartData = await s3Client.send(createMultipartUploadCommand);
		console.log(`UploadId : ${multipartData.UploadId}`);

		let urls = [];
		for (let index = 0; index < parts; index++) {
			const command = new UploadPartCommand({
				Bucket: process.env.file_bucket_name,
				Key: org_file_name,
				UploadId: multipartData.UploadId,
				PartNumber: index + 1,
			});
			const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 6000 });
			urls.push(signedUrl);
		}

		return {
			status: 200,
			response: {
				result: "success",
				uploadId: multipartData.UploadId,
				urls,
				size_unit: sizeUnit,
			},
		};
	} catch (e) {
		console.log(e);
		return { predefinedError: apiSpec.errors.unexpected_error };
	}
}
exports.handler = async (event, context) => {
	return await handleHttpRequest(event, context, apiSpec, handler);
};
