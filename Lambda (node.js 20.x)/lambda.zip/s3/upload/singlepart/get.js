const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
var Base64 = require("js-base64").Base64;
var moment = require('moment');
const { handleHttpRequest } = require("slsberry");
const apiSpec = {
	category: "http",
	event: [
		{
			type: "REST",
			method: "Get",
		},
	],
	desc: "single presigned url들을 생성한다",
	parameters: {
		user_id: { req: true, type: "string", desc: "user_id" },

		type: { req: true, type: "string", desc: "type" },
		org_file_name: { req: true, type: "string", desc: "원본 파일 이름름" },
	},
	errors: {
		unexpected_error: { status_code: 500, reason: "알 수 없는 에러" },
	},
	responses: {
		description: "",
		content: "application/json",
		schema: {
			type: "object",
			properties: {
				hashKey: { type: "String", desc: "hash_key" },
			},
		},
	},
};
exports.apiSpec = apiSpec;



async function handler(inputObject, event) {
	const { user_id, type, org_file_name } = inputObject;

	console.log(inputObject);

	try {
		let metadata = {};
		metadata["user_id"] = user_id;
		metadata["type"] = type;
		// Encoding Korean characters in base64 as needed
		metadata["org_file_name"] = Base64.encode(org_file_name);

		const s3Params = {
			Bucket: process.env.file_bucket_name,
			Key: org_file_name,

			Metadata: metadata
		};
		console.log(s3Params);

		const s3 = new S3Client({});
		const command = new PutObjectCommand(s3Params);
		const presignedUrl = await getSignedUrl(s3, command, { expiresIn: 6000 });

		return {
			status: 200,
			response: {
				result: "success",
				url: presignedUrl
			},
		};
	} catch (e) {
		console.log(e);
		return { predefinedError: apiSpec.errors.unexpected_error };
	}
}
exports.handler = async (event, context) => {
	return await handleHttpRequest(event, context, apiSpec, handler);
};
