const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { handleHttpRequest } = require("slsberry");
var moment = require('moment');
const apiSpec = {
	category: "http",
	event: [
		{
			type: "REST",
			method: "Get",
		},
	],
	desc: "다운로드 presigned url을 생성한다",
	parameters: {
		fileKey: { req: true, type: "string", desc: "fileKey" },
		expire_in: { req: true, type: "Integer", desc: "expire_in", default: 6000 },
	},
	errors: {
		unexpected_error: { status_code: 500, reason: "알 수 없는 에러" },
	},
	responses: {
		description: "",
		content: "application/json",
		schema: {
			type: "object",
			properties: {

			},
		},
	},
};
exports.apiSpec = apiSpec;


async function handler(inputObject, event) {
	const { fileKey } = inputObject;

	console.log(inputObject);
	// Initialize the S3 Client
	const s3 = new S3Client({});

	try {
		const s3Params = {
			Bucket: process.env.file_bucket_name,
			Key: fileKey,
			Expires: moment().add(6000, 'seconds').toDate(),
		};

		// Create the command for getting the object
		const command = new GetObjectCommand(s3Params);
		// Get the signed URL
		const signedUrl = await getSignedUrl(s3, command, { expiresIn: parseInt(inputObject.expire_in) });

		console.log(signedUrl);

		return {
			status: 200,
			response: {
				result: "success",
				url: signedUrl
			}
		};
	} catch (e) {
		console.log(e);
		return { predefinedError: apiSpec.errors.unexpected_error };
	}
}
exports.handler = async (event, context) => {
	return await handleHttpRequest(event, context, apiSpec, handler);
};
